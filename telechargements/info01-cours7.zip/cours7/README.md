# Cours 7 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est le bloc,
la lettre l'ordre dans le bloc. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 7b | Deux effets pour la fenêtre du train | `7b_train/` |  |
