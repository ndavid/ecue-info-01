# Cours 5 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est le bloc,
la lettre l'ordre dans le bloc. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 1a | Les ordres de grandeur de votre poste | `1a_mesures/` |  |
| 2a | Une clé SSH sur votre compte | `2a_cle_ssh/` |  |
| 3a | Un secret dans l'historique | `3a_secret_historique/` | facultatif |
