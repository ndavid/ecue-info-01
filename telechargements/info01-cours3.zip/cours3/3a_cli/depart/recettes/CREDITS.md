# Photos

Wikimedia Commons, réduites à 960 px de large.

- `crepes/photo.jpg` : Line 1921, CC0, <https://commons.wikimedia.org/wiki/File:Crêpe_à_la_confiture_de_fruit.jpg>
- `mousse_chocolat/photo.jpg` : Theo Crazzolara, CC BY 2.0, <https://commons.wikimedia.org/wiki/File:Mousse_au_chocolat_(31043136424).jpg>
- `salade_lentilles/photo.jpg` : Benoît Prieur, CC0, <https://commons.wikimedia.org/wiki/File:Salade_de_lentilles_au_Bouillon_de_Lyon_en_février_2023.jpg>
- `pate_pizza/photo.jpg` : Jon Sullivan, domaine public, <https://commons.wikimedia.org/wiki/File:Making_pizza_dough_in_kitchen.jpg>
