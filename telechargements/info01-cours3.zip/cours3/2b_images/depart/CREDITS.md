# Images

- `vague.jpg` : Katsushika Hokusai, *Under the Wave off Kanagawa*, The Metropolitan Museum of Art, open access (CC0), <https://www.metmuseum.org/art/collection/search/45434>
