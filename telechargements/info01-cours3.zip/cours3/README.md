# Cours 3 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est le bloc,
la lettre l'ordre dans le bloc. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 0a | Un environnement pour la séance | `0a_environnement/` | facultatif |
| 1a | Ouvrir le notebook de la recette | `1a_recette/` |  |
| 2a | Lire et écrire des fichiers texte | `2a_fichiers/` |  |
| 2b | Texte et binaire : les images PGM | `2b_images/` |  |
| 3a | Une ligne de commande pour la recette | `3a_cli/` |  |
