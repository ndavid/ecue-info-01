# Cours 1 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est le bloc,
la lettre l'ordre dans le bloc. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 1a | Fichiers, formats et extensions | `1a_formats/` |  |
| 1b | Un .odt est une archive ZIP | `1b_archive_odt/` | facultatif |
| 2a | Configurer l'éditeur de code, et lancer un programme | `2a_vscode_python/` |  |
| 2b | Trois programmes fautifs | `2b_erreurs/` |  |
| 2c | Le même programme en C++ | `2c_hello_cpp/` | facultatif |
| 3a | Mettre en forme une recette en Markdown | `3a_markdown/` |  |
| 3b | Le notebook, ouvert de trois façons | `3b_notebooks/` |  |
| 4a | Installer un projet Python, et décrire son installation | `4a_recette/` |  |
| 4b | Le client, le noyau, et où ils sont installés | `4b_noyaux/` | facultatif |
| 5a | Installer un projet en lisant son README | `4c_trajet/` | facultatif |
