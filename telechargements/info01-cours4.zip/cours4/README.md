# Cours 4 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est le bloc,
la lettre l'ordre dans le bloc. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 4a | La montre du Lapin blanc | `4a_montre/` |  |
| 4b | La Vague en tourbillon | `4b_tourbillon/` |  |
| 4c | La fenêtre du train | `4c_train/` |  |
