# Décor

Les images de `decor/` sont dessinées par `make_data.py` (ImageMagick, des polygones de couleur unie), d'après la scène de la mer du clip « Moon » de Kid Francescoli, réalisé par le collectif Cauboyz (2017). Le clip a été tourné avec des décors en carton posés sur une table tournante : <https://www.youtube.com/watch?v=fdixQDPA2h0>.
